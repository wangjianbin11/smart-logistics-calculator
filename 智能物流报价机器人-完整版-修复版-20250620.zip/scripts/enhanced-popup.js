// 增强版弹窗界面 - 支持智能比价功能
document.addEventListener('DOMContentLoaded', async function() {
    const calculator = new EnhancedPriceCalculator();
    await calculator.initialize();
    
    // DOM 元素获取
    const elements = {
        companySelect: document.getElementById('company'),
        serviceSelect: document.getElementById('service'),
        countrySelect: document.getElementById('country'),
        zoneSelect: document.getElementById('zone'),
        weightInput: document.getElementById('weight'),
        productTypeSelect: document.getElementById('productType'),
        calculateBtn: document.getElementById('calculate'),
        compareBtn: document.getElementById('compareAll'),
        resultDiv: document.getElementById('result'),
        historyBtn: document.getElementById('viewHistory'),
        settingsBtn: document.getElementById('settings')
    };

    // 初始化界面
    initializeInterface();

    // 事件监听器
    elements.companySelect?.addEventListener('change', onCompanyChange);
    elements.serviceSelect?.addEventListener('change', onServiceChange);
    elements.countrySelect?.addEventListener('change', onCountryChange);
    elements.calculateBtn?.addEventListener('click', onCalculate);
    elements.compareBtn?.addEventListener('click', onCompareAll);
    elements.historyBtn?.addEventListener('click', onViewHistory);
    elements.settingsBtn?.addEventListener('click', onSettings);

    // 初始化界面数据
    function initializeInterface() {
        try {
            // 加载物流公司
            loadCompanies();
            
            // 加载产品类型
            loadProductTypes();
            
            console.log('Enhanced popup initialized with comparison features');
        } catch (error) {
            console.error('Failed to initialize interface:', error);
            showError('界面初始化失败');
        }
    }

    // 加载物流公司
    function loadCompanies() {
        if (!elements.companySelect) return;
        
        const companies = calculator.getCompanies();
        elements.companySelect.innerHTML = '<option value="">请选择物流公司</option>';
        
        companies.forEach(company => {
            const option = document.createElement('option');
            option.value = company;
            option.textContent = company;
            elements.companySelect.appendChild(option);
        });
    }

    // 加载产品类型（已移除，统一处理为服装类）
    function loadProductTypes() {
        // 产品类型选择已移除，统一按服装类处理
        if (elements.productTypeSelect) {
            elements.productTypeSelect.style.display = 'none';
        }
    }

    // 物流公司选择变化
    function onCompanyChange() {
        const company = elements.companySelect?.value;
        if (!company) {
            clearSelects(['service', 'country', 'zone']);
            return;
        }
        
        loadServices(company);
        clearSelects(['country', 'zone']);
    }

    // 加载服务
    function loadServices(company) {
        if (!elements.serviceSelect) return;
        
        const services = calculator.getServices(company);
        elements.serviceSelect.innerHTML = '<option value="">请选择服务类型</option>';
        
        services.forEach(service => {
            const option = document.createElement('option');
            option.value = service;
            option.textContent = service;
            elements.serviceSelect.appendChild(option);
        });
    }

    // 服务选择变化
    function onServiceChange() {
        const company = elements.companySelect?.value;
        const service = elements.serviceSelect?.value;
        
        if (!company || !service) {
            clearSelects(['country', 'zone']);
            return;
        }
        
        loadCountries(company, service);
        clearSelects(['zone']);
    }

    // 加载国家
    function loadCountries(company, service) {
        if (!elements.countrySelect) return;
        
        const countries = calculator.getCountries(company, service);
        elements.countrySelect.innerHTML = '<option value="">请选择目的国家</option>';
        
        countries.forEach(country => {
            const option = document.createElement('option');
            option.value = country;
            option.textContent = country;
            elements.countrySelect.appendChild(option);
        });
    }

    // 国家选择变化
    function onCountryChange() {
        const company = elements.companySelect?.value;
        const service = elements.serviceSelect?.value;
        const country = elements.countrySelect?.value;
        
        if (!company || !service || !country) {
            clearSelects(['zone']);
            return;
        }
        
        loadZones(company, service, country);
    }

    // 加载区域（如澳大利亚的分区）
    function loadZones(company, service, country) {
        if (!elements.zoneSelect) return;
        
        const zones = calculator.getZones(company, service, country);
        
        if (zones && zones.length > 0) {
            elements.zoneSelect.style.display = 'block';
            elements.zoneSelect.innerHTML = '<option value="">请选择区域</option>';
            
            zones.forEach(zone => {
                const option = document.createElement('option');
                option.value = zone;
                option.textContent = zone;
                elements.zoneSelect.appendChild(option);
            });
        } else {
            elements.zoneSelect.style.display = 'none';
            elements.zoneSelect.innerHTML = '';
        }
    }

    // 清空选择框
    function clearSelects(selectNames) {
        selectNames.forEach(name => {
            const element = elements[name + 'Select'];
            if (element) {
                element.innerHTML = name === 'zone' ? '' : '<option value="">请选择</option>';
                if (name === 'zone') element.style.display = 'none';
            }
        });
    }

    // 单独计算
    async function onCalculate() {
        try {
            const formData = getFormData();
            if (!validateFormData(formData, false)) return;
            
            showLoading('正在计算报价...');
            
            const quote = await calculator.calculateSingleQuote(
                formData.company,
                formData.service,
                formData.country,
                formData.weight,
                formData.productType,
                formData.zone
            );
            
            displaySingleResult(quote);
            
        } catch (error) {
            console.error('Calculate error:', error);
            showError(error.message);
        }
    }

    // 智能比价
    async function onCompareAll() {
        try {
            const formData = getFormData();
            if (!validateFormData(formData, true)) return;
            
            showLoading('正在比价中，请稍候...');
            
            const comparisonResult = await calculator.compareAllQuotes(
                formData.country,
                formData.weight,
                formData.productType,
                formData.zone
            );
            
            if (comparisonResult.comparisons.length === 0) {
                showError('没有找到适合的物流方案，请检查重量和目的地设置');
                return;
            }
            
            displayComparisonResult(comparisonResult);
            
            // 保存比价历史
            await calculator.saveComparisonResult(comparisonResult);
            
        } catch (error) {
            console.error('Compare error:', error);
            showError('比价失败: ' + error.message);
        }
    }

    // 获取表单数据
    function getFormData() {
        return {
            company: elements.companySelect?.value || '',
            service: elements.serviceSelect?.value || '',
            country: elements.countrySelect?.value || '',
            zone: elements.zoneSelect?.value || '',
            weight: parseFloat(elements.weightInput?.value || '0'),
            productType: '服装' // 统一按服装类处理
        };
    }

    // 验证表单数据
    function validateFormData(formData, isComparison) {
        if (!formData.country) {
            showError('请选择目的国家');
            return false;
        }
        
        if (!formData.weight || formData.weight <= 0) {
            showError('请输入有效的重量');
            return false;
        }
        
        if (!isComparison) {
            if (!formData.company) {
                showError('请选择物流公司');
                return false;
            }
            
            if (!formData.service) {
                showError('请选择服务类型');
                return false;
            }
        }
        
        return true;
    }

    // 显示单个计算结果
    function displaySingleResult(quote) {
        if (!elements.resultDiv) return;
        
        const html = `
            <div class="single-result">
                <h3>📊 报价结果</h3>
                <div class="quote-card">
                    <div class="quote-header">
                        <span class="company">${quote.company}</span>
                        <span class="service">${quote.service}</span>
                    </div>
                    <div class="quote-price">
                        <div class="main-price">¥${quote.totals.finalPriceCny.toFixed(2)}</div>
                        <div class="usd-price">≈$${quote.totals.finalPriceUsd.toFixed(2)}</div>
                    </div>
                    <div class="quote-details">
                        <div class="detail-row">
                            <span class="label">目的地:</span>
                            <span class="value">${quote.country} ${quote.zone}</span>
                        </div>
                        <div class="detail-row">
                            <span class="label">重量:</span>
                            <span class="value">${quote.weight}kg</span>
                        </div>
                        <div class="detail-row">
                            <span class="label">运费:</span>
                            <span class="value">¥${quote.totals.shippingCost.toFixed(2)}</span>
                        </div>
                        <div class="detail-row">
                            <span class="label">计算:</span>
                            <span class="value">${quote.shipping.calculation.formula}</span>
                        </div>
                        <div class="detail-row">
                            <span class="label">时效:</span>
                            <span class="value">${quote.shipping.details.timeframe}</span>
                        </div>
                    </div>
                </div>
                <div class="actions">
                    <button class="btn-compare" onclick="triggerCompareAll()">🔄 智能比价</button>
                    <button class="btn-copy" onclick="copyResult('${encodeURIComponent(JSON.stringify(quote))}')">📋 复制结果</button>
                </div>
            </div>
        `;
        
        elements.resultDiv.innerHTML = html;
    }

    // 显示比价结果
    function displayComparisonResult(result) {
        if (!elements.resultDiv) return;
        
        const { country, weight, productType, zone, comparisons, best } = result;
        
        let html = `
            <div class="comparison-result">
                <div class="comparison-header">
                    <h3>🚚 智能比价结果</h3>
                    <div class="comparison-info">
                        <span>📍 ${country} ${zone}</span>
                        <span>⚖️ ${weight}kg</span>
                        <span>📦 ${productType}</span>
                        <span>🔍 ${comparisons.length}个方案</span>
                    </div>
                </div>
        `;
        
        if (best) {
            html += `
                <div class="best-option">
                    <h4>💰 推荐方案</h4>
                    <div class="option-card best">
                        <div class="option-header">
                            <span class="company">${best.company}</span>
                            <span class="service">${best.service}</span>
                            <span class="badge best-badge">最便宜</span>
                        </div>
                        <div class="option-price">
                            <div class="main-price">¥${best.totals.finalPriceCny.toFixed(2)}</div>
                            <div class="usd-price">≈$${best.totals.finalPriceUsd.toFixed(2)}</div>
                        </div>
                        <div class="option-details">
                            <div class="detail-item">
                                <span class="label">运费:</span>
                                <span class="value">¥${best.totals.shippingCost.toFixed(2)}</span>
                            </div>
                            <div class="detail-item">
                                <span class="label">时效:</span>
                                <span class="value">${best.shipping.details.timeframe}</span>
                            </div>
                            <div class="detail-item">
                                <span class="label">计算:</span>
                                <span class="value">${best.shipping.calculation.formula}</span>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }
        
        if (comparisons.length > 1) {
            html += `
                <div class="all-options">
                    <h4>📋 全部方案对比</h4>
                    <div class="options-list">
            `;
            
            comparisons.forEach((quote, index) => {
                const isFirst = index === 0;
                const savings = index > 0 ? (quote.totals.finalPriceCny - best.totals.finalPriceCny).toFixed(2) : 0;
                
                html += `
                    <div class="option-card ${isFirst ? 'best' : ''}">
                        <div class="option-rank">${index + 1}</div>
                        <div class="option-content">
                            <div class="option-header">
                                <span class="company">${quote.company}</span>
                                <span class="service">${quote.service}</span>
                                ${isFirst ? '<span class="badge best-badge">推荐</span>' : ''}
                                ${savings > 0 ? `<span class="badge price-diff">+¥${savings}</span>` : ''}
                            </div>
                            <div class="option-price">
                                <div class="main-price">¥${quote.totals.finalPriceCny.toFixed(2)}</div>
                            </div>
                            <div class="option-quick-info">
                                <span>⏰ ${quote.shipping.details.timeframe}</span>
                                <span>🚛 ¥${quote.totals.shippingCost.toFixed(2)}</span>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            html += `
                    </div>
                </div>
            `;
        }
        
        html += `
                <div class="actions">
                    <button class="btn-copy" onclick="copyComparisonResult('${encodeURIComponent(JSON.stringify(result))}')">📋 复制比价报告</button>
                    <button class="btn-history" onclick="viewHistory()">📚 查看历史</button>
                </div>
            </div>
        `;
        
        elements.resultDiv.innerHTML = html;
    }

    // 显示加载状态
    function showLoading(message) {
        if (!elements.resultDiv) return;
        elements.resultDiv.innerHTML = `
            <div class="loading">
                <div class="loading-spinner"></div>
                <div class="loading-text">${message}</div>
            </div>
        `;
    }

    // 显示错误信息
    function showError(message) {
        if (!elements.resultDiv) return;
        elements.resultDiv.innerHTML = `
            <div class="error">
                <div class="error-icon">❌</div>
                <div class="error-text">${message}</div>
            </div>
        `;
    }

    // 查看历史记录
    async function onViewHistory() {
        try {
            const history = await calculator.getComparisonHistory();
            displayHistory(history);
        } catch (error) {
            console.error('Failed to load history:', error);
            showError('加载历史记录失败');
        }
    }

    // 显示历史记录
    function displayHistory(history) {
        if (!elements.resultDiv) return;
        
        if (history.length === 0) {
            elements.resultDiv.innerHTML = `
                <div class="no-history">
                    <div class="no-history-icon">📚</div>
                    <div class="no-history-text">暂无比价历史记录</div>
                </div>
            `;
            return;
        }
        
        let html = `
            <div class="history-view">
                <div class="history-header">
                    <h3>📚 比价历史记录</h3>
                    <button class="btn-back" onclick="clearResults()">返回</button>
                </div>
                <div class="history-list">
        `;
        
        history.forEach((record, index) => {
            const date = new Date(record.timestamp).toLocaleString('zh-CN');
            const best = record.best;
            
            html += `
                <div class="history-item">
                    <div class="history-info">
                        <div class="history-destination">📍 ${record.country} ${record.zone}</div>
                        <div class="history-weight">⚖️ ${record.weight}kg</div>
                        <div class="history-date">📅 ${date}</div>
                    </div>
                    ${best ? `
                        <div class="history-best">
                            <div class="history-company">${best.company} - ${best.service}</div>
                            <div class="history-price">¥${best.totals.finalPriceCny.toFixed(2)}</div>
                        </div>
                    ` : ''}
                </div>
            `;
        });
        
        html += `
                </div>
            </div>
        `;
        
        elements.resultDiv.innerHTML = html;
    }

    // 设置
    function onSettings() {
        // 打开设置页面
        chrome.tabs.create({ url: 'options.html' });
    }

    // 全局函数（供HTML调用）
    window.triggerCompareAll = () => onCompareAll();
    window.copyResult = (encodedData) => {
        try {
            const quote = JSON.parse(decodeURIComponent(encodedData));
            const report = calculator.generateComparisonReport({ 
                comparisons: [quote], 
                best: quote,
                country: quote.country,
                weight: quote.weight,
                productType: quote.productType,
                zone: quote.zone
            });
            navigator.clipboard.writeText(report);
            showMessage('结果已复制到剪贴板');
        } catch (error) {
            console.error('Copy failed:', error);
        }
    };
    
    window.copyComparisonResult = (encodedData) => {
        try {
            const result = JSON.parse(decodeURIComponent(encodedData));
            const report = calculator.generateComparisonReport(result);
            navigator.clipboard.writeText(report);
            showMessage('比价报告已复制到剪贴板');
        } catch (error) {
            console.error('Copy failed:', error);
        }
    };
    
    window.viewHistory = () => onViewHistory();
    window.clearResults = () => {
        if (elements.resultDiv) elements.resultDiv.innerHTML = '';
    };

    // 显示提示信息
    function showMessage(message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message';
        messageDiv.textContent = message;
        document.body.appendChild(messageDiv);
        
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.parentNode.removeChild(messageDiv);
            }
        }, 2000);
    }
});