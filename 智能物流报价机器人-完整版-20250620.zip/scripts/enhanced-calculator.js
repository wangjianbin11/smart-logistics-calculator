// 增强版价格计算器，支持智能比价功能
class EnhancedPriceCalculator {
    constructor() {
        this.database = new LogisticsDatabase();
        this.profitSettings = {
            profit_rate: 0.15,     // 15%利润率
            markup_rate: 0.05,     // 5%加价率
            min_profit: 10         // 最低利润10元
        };
        this.exchangeRate = 7;     // CNY到USD汇率
    }

    // 初始化
    async initialize() {
        try {
            const data = await chrome.storage.local.get(['profit_settings', 'exchange_rate']);
            if (data.profit_settings) {
                this.profitSettings = { ...this.profitSettings, ...data.profit_settings };
            }
            if (data.exchange_rate) {
                this.exchangeRate = data.exchange_rate;
            }
            console.log('Enhanced Calculator initialized with comparison features');
        } catch (error) {
            console.error('Failed to load settings:', error);
        }
    }

    // 获取所有物流公司
    getCompanies() {
        return this.database.getCompanies();
    }

    // 获取物流公司的服务
    getServices(company) {
        return this.database.getServices(company);
    }

    // 获取服务的国家列表
    getCountries(company, service) {
        return this.database.getCountries(company, service);
    }

    // 获取国家的区域列表（如澳大利亚）
    getZones(company, service, country) {
        return this.database.getZones(company, service, country);
    }

    // 根据重量找到对应的费率段
    findWeightTier(weightTiers, weight) {
        for (let tier of weightTiers) {
            if (weight >= tier.minWeight && weight <= tier.maxWeight) {
                return tier;
            }
        }
        // 如果没找到精确匹配，返回最后一个区间（通常是最大重量段）
        return weightTiers[weightTiers.length - 1];
    }

    // 计算物流费用（万邦物流规则：max(重量×公斤价, 操作费)）
    calculateLogisticsCost(countryCode, serviceCode, weight) {
        if (!this.logisticsData || !this.logisticsData[countryCode]) {
            throw new Error(`未找到国家数据: ${countryCode}`);
        }

        const country = this.logisticsData[countryCode];
        if (!country.services[serviceCode]) {
            throw new Error(`未找到服务数据: ${serviceCode}`);
        }

        const service = country.services[serviceCode];
        const weightTier = this.findWeightTier(service.weightTiers, weight);

        if (!weightTier) {
            throw new Error(`重量 ${weight}kg 超出服务范围`);
        }

        // 万邦物流计费规则：取重量费和操作费的最大值
        const weightCost = weight * weightTier.pricePerKg;
        const operationFee = weightTier.operationFee;
        const logisticsCost = Math.max(weightCost, operationFee);

        return {
            logisticsCost,
            weightCost,
            operationFee,
            pricePerKg: weightTier.pricePerKg,
            weightTier,
            service
        };
    }

    // 计算单个物流公司的完整报价
    async calculateSingleQuote(company, service, country, weight, productType = '服装', zone = null) {
        try {
            // 获取物流费用计算结果
            const shippingResult = this.database.calculateShipping(company, service, country, weight, zone);
            
            // 简化关税计算（实际应根据国家和产品类型）
            const tariffRate = this.getTariffRate(country, productType);
            const estimatedProductValue = weight * 50; // 假设每公斤产品价值50元
            const tariffCost = estimatedProductValue * tariffRate;
            
            // 总成本
            const totalCost = shippingResult.calculation.totalCost + tariffCost;
            
            // 利润计算
            const profitByRate = totalCost * this.profitSettings.profit_rate;
            const profitAmount = Math.max(profitByRate, this.profitSettings.min_profit);
            
            // 最终价格
            const finalPriceCny = totalCost + profitAmount;
            const finalPriceUsd = finalPriceCny / this.exchangeRate;
            
            return {
                company,
                service,
                country,
                zone: zone || '',
                weight,
                productType,
                shipping: shippingResult,
                tariff: {
                    rate: tariffRate,
                    cost: tariffCost,
                    estimatedProductValue
                },
                profit: {
                    rate: this.profitSettings.profit_rate,
                    amount: profitAmount
                },
                totals: {
                    shippingCost: shippingResult.calculation.totalCost,
                    tariffCost: tariffCost,
                    totalCost: totalCost,
                    finalPriceCny: finalPriceCny,
                    finalPriceUsd: finalPriceUsd
                },
                timestamp: new Date().toISOString()
            };
        } catch (error) {
            throw new Error(`${company} ${service} 计算失败: ${error.message}`);
        }
    }

    // 智能比价功能：比较所有可用的物流方案
    async compareAllQuotes(country, weight, productType = '服装', zone = null) {
        const comparisons = [];
        const companies = this.getCompanies();
        
        console.log(`开始比价: ${country} ${weight}kg ${productType} ${zone || ''}`);
        
        for (let company of companies) {
            const services = this.getServices(company);
            
            for (let service of services) {
                // 检查是否支持该国家
                const countries = this.getCountries(company, service);
                if (!countries.includes(country)) {
                    console.log(`${company} ${service} 不支持 ${country}`);
                    continue;
                }
                
                try {
                    const quote = await this.calculateSingleQuote(company, service, country, weight, productType, zone);
                    comparisons.push(quote);
                    console.log(`${company} ${service}: ${quote.totals.finalPriceCny}元`);
                } catch (error) {
                    console.warn(`${company} ${service} 计算失败:`, error.message);
                }
            }
        }
        
        // 按最终价格排序
        comparisons.sort((a, b) => a.totals.finalPriceCny - b.totals.finalPriceCny);
        
        return {
            country,
            weight,
            productType,
            zone: zone || '',
            comparisons,
            best: comparisons[0] || null,
            compareCount: comparisons.length,
            timestamp: new Date().toISOString()
        };
    }

    // 生成详细的比价报告
    generateComparisonReport(comparisonResult) {
        if (!comparisonResult || !comparisonResult.comparisons.length) {
            return '❌ 没有找到可用的物流方案';
        }
        
        const { country, weight, productType, zone, comparisons, best } = comparisonResult;
        
        let report = `🚚 智能物流比价报告\n`;
        report += `════════════════════════\n`;
        report += `📍 目的地: ${country} ${zone}\n`;
        report += `⚖️ 重量: ${weight}kg\n`;
        report += `📦 产品类型: ${productType}\n`;
        report += `🔍 找到 ${comparisons.length} 个方案\n\n`;
        
        // 最优方案
        if (best) {
            report += `💰 最优方案 (最便宜)\n`;
            report += `────────────────────\n`;
            report += `🏢 ${best.company} - ${best.service}\n`;
            report += `💵 总报价: ¥${best.totals.finalPriceCny.toFixed(2)} (≈$${best.totals.finalPriceUsd.toFixed(2)})\n`;
            report += `🚛 运费: ¥${best.totals.shippingCost.toFixed(2)}\n`;
            report += `📊 计算: ${best.shipping.calculation.formula}\n`;
            report += `⏰ 时效: ${best.shipping.details.timeframe}\n`;
            report += `📏 尺寸限制: ${best.shipping.details.sizeLimit}\n`;
            if (best.shipping.details.note) {
                report += `⚠️ 备注: ${best.shipping.details.note}\n`;
            }
            report += `\n`;
        }
        
        // 所有方案对比
        if (comparisons.length > 1) {
            report += `📋 全部方案对比\n`;
            report += `────────────────────\n`;
            comparisons.forEach((quote, index) => {
                const isRecommended = index === 0 ? '🏆 ' : `${index + 1}. `;
                report += `${isRecommended}${quote.company} - ${quote.service}\n`;
                report += `   💵 ¥${quote.totals.finalPriceCny.toFixed(2)} | ⏰ ${quote.shipping.details.timeframe}\n`;
                report += `   🚛 运费: ¥${quote.totals.shippingCost.toFixed(2)} | 📊 ${quote.shipping.calculation.formula}\n`;
                if (index < comparisons.length - 1) report += `\n`;
            });
        }
        
        return report;
    }

    // 简化的关税率计算
    getTariffRate(country, productType) {
        const tariffRates = {
            '美国': { '服装': 0.1, '化妆品': 0.08, '电子产品': 0.15 },
            '英国': { '服装': 0.12, '化妆品': 0.05, '电子产品': 0.20 },
            '德国': { '服装': 0.12, '化妆品': 0.05, '电子产品': 0.19 },
            '法国': { '服装': 0.12, '化妆品': 0.05, '电子产品': 0.20 },
            '意大利': { '服装': 0.12, '化妆品': 0.05, '电子产品': 0.22 },
            '西班牙': { '服装': 0.12, '化妆品': 0.05, '电子产品': 0.21 },
            '日本': { '服装': 0.10, '化妆品': 0.00, '电子产品': 0.00 },
            '澳大利亚': { '服装': 0.05, '化妆品': 0.05, '电子产品': 0.05 },
            '加拿大': { '服装': 0.18, '化妆品': 0.065, '电子产品': 0.065 }
        };
        
        const countryRates = tariffRates[country];
        if (!countryRates) return 0.1; // 默认10%
        
        return countryRates[productType] || countryRates['服装'] || 0.1;
    }

    // 保存比价结果
    async saveComparisonResult(result) {
        try {
            const savedResults = await chrome.storage.local.get(['comparison_history']) || { comparison_history: [] };
            const history = savedResults.comparison_history || [];
            
            // 保留最近20次比价记录
            history.unshift(result);
            if (history.length > 20) {
                history.splice(20);
            }
            
            await chrome.storage.local.set({ comparison_history: history });
        } catch (error) {
            console.error('Failed to save comparison result:', error);
        }
    }

    // 获取比价历史
    async getComparisonHistory() {
        try {
            const data = await chrome.storage.local.get(['comparison_history']);
            return data.comparison_history || [];
        } catch (error) {
            console.error('Failed to load comparison history:', error);
            return [];
        }
    }

    // 生成报价文本（用于复制）
    generateQuoteText(quote) {
        return `
🎯 智能报价单

📦 产品信息:
• 产品名称: ${quote.productName}
• 重量: ${quote.weight}kg
• 单价: ¥${quote.unitPriceCny}/kg

🚚 物流信息:
• 目的地: ${quote.logistics.countryName}
• 服务: ${quote.logistics.serviceName}
• 时效: ${quote.logistics.deliveryTime}天
• 重量段: ${quote.logistics.weightTier.minWeight}-${quote.logistics.weightTier.maxWeight}kg

💰 费用明细:
• 产品成本: ¥${quote.productCost.toFixed(2)} (${quote.breakdown.productCost.percentage}%)
• 物流费用: ¥${quote.logistics.cost.toFixed(2)} (${quote.breakdown.logisticsCost.percentage}%)
• 关税费用: ¥${quote.tariff.cost.toFixed(2)} (${quote.breakdown.tariffCost.percentage}%)
• 利润: ¥${quote.profit.amount.toFixed(2)} (${quote.breakdown.profitAmount.percentage}%)

🔥 最终报价:
• 人民币: ¥${quote.totals.finalCny.toFixed(2)}
• 美元: $${quote.totals.finalUsd.toFixed(2)} (汇率: ${quote.totals.exchangeRate})

⚡ 由智能报价机器人生成 ${new Date().toLocaleString('zh-CN')}
`.trim();
    }

    // 更新利润设置
    async updateProfitSettings(settings) {
        this.profitSettings = { ...this.profitSettings, ...settings };
        await chrome.storage.local.set({ 'profit_settings': this.profitSettings });
    }

    // 更新汇率
    async updateExchangeRate(rate) {
        this.exchangeRate = rate;
        await chrome.storage.local.set({ 'exchange_rate': rate });
    }
}

// 导出供其他模块使用
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EnhancedPriceCalculator;
} else {
    window.EnhancedPriceCalculator = EnhancedPriceCalculator;
} 