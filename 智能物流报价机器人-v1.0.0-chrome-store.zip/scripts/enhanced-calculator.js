// 增强版价格计算器，支持万邦物流复杂数据结构
class EnhancedPriceCalculator {
    constructor() {
        this.logisticsData = null;
        this.profitSettings = {
            profit_rate: 0.15,     // 15%利润率
            markup_rate: 0.05,     // 5%加价率
            min_profit: 10         // 最低利润10元
        };
        this.exchangeRate = 7;     // CNY到USD汇率
    }

    // 初始化，加载万邦物流数据
    async initialize() {
        try {
            const data = await chrome.storage.local.get(['logistics_rates', 'profit_settings']);
            this.logisticsData = data.logistics_rates;
            if (data.profit_settings) {
                this.profitSettings = { ...this.profitSettings, ...data.profit_settings };
            }
            console.log('Enhanced Calculator initialized with Wanbo logistics data');
        } catch (error) {
            console.error('Failed to load logistics data:', error);
        }
    }

    // 获取可用的国家列表
    getAvailableCountries() {
        if (!this.logisticsData) return [];
        return Object.keys(this.logisticsData).map(countryCode => ({
            code: countryCode,
            name: this.logisticsData[countryCode].name
        }));
    }

    // 获取指定国家的服务列表
    getCountryServices(countryCode) {
        if (!this.logisticsData || !this.logisticsData[countryCode]) return [];
        const country = this.logisticsData[countryCode];
        return Object.keys(country.services).map(serviceCode => ({
            code: serviceCode,
            name: country.services[serviceCode].name,
            deliveryTime: country.services[serviceCode].deliveryTime,
            weightLimit: country.services[serviceCode].weightLimit,
            sizeLimit: country.services[serviceCode].sizeLimit
        }));
    }

    // 根据重量找到对应的费率段
    findWeightTier(weightTiers, weight) {
        for (let tier of weightTiers) {
            if (weight >= tier.minWeight && weight <= tier.maxWeight) {
                return tier;
            }
        }
        // 如果没找到精确匹配，返回最后一个区间（通常是最大重量段）
        return weightTiers[weightTiers.length - 1];
    }

    // 计算物流费用（万邦物流规则：max(重量×公斤价, 操作费)）
    calculateLogisticsCost(countryCode, serviceCode, weight) {
        if (!this.logisticsData || !this.logisticsData[countryCode]) {
            throw new Error(`未找到国家数据: ${countryCode}`);
        }

        const country = this.logisticsData[countryCode];
        if (!country.services[serviceCode]) {
            throw new Error(`未找到服务数据: ${serviceCode}`);
        }

        const service = country.services[serviceCode];
        const weightTier = this.findWeightTier(service.weightTiers, weight);

        if (!weightTier) {
            throw new Error(`重量 ${weight}kg 超出服务范围`);
        }

        // 万邦物流计费规则：取重量费和操作费的最大值
        const weightCost = weight * weightTier.pricePerKg;
        const operationFee = weightTier.operationFee;
        const logisticsCost = Math.max(weightCost, operationFee);

        return {
            logisticsCost,
            weightCost,
            operationFee,
            pricePerKg: weightTier.pricePerKg,
            weightTier,
            service
        };
    }

    // 计算完整报价
    async calculateQuote(productName, weight, unitPriceCny, countryCode, serviceCode) {
        if (!this.logisticsData) {
            await this.initialize();
        }

        if (!this.logisticsData) {
            throw new Error('请先导入万邦物流数据');
        }

        // 基础产品成本
        const productCost = weight * unitPriceCny;

        // 物流费用计算
        const logisticsResult = this.calculateLogisticsCost(countryCode, serviceCode, weight);

        // 简化关税计算（暂时使用固定比例）
        const tariffRate = 0.1; // 10%关税率，实际应根据国家和产品类型计算
        const tariffCost = productCost * tariffRate;

        // 总成本
        const totalCost = productCost + logisticsResult.logisticsCost + tariffCost;

        // 利润计算
        const profitByRate = totalCost * this.profitSettings.profit_rate;
        const profitAmount = Math.max(profitByRate, this.profitSettings.min_profit);

        // 最终人民币价格
        const finalPriceCny = totalCost + profitAmount;

        // 转换为美元价格
        const finalPriceUsd = finalPriceCny / this.exchangeRate;

        // 构建完整报价信息
        const quote = {
            productName,
            weight,
            unitPriceCny,
            productCost,
            logistics: {
                countryCode,
                countryName: this.logisticsData[countryCode].name,
                serviceCode,
                serviceName: logisticsResult.service.name,
                cost: logisticsResult.logisticsCost,
                weightCost: logisticsResult.weightCost,
                operationFee: logisticsResult.operationFee,
                pricePerKg: logisticsResult.pricePerKg,
                deliveryTime: logisticsResult.service.deliveryTime,
                weightTier: logisticsResult.weightTier
            },
            tariff: {
                rate: tariffRate,
                cost: tariffCost
            },
            profit: {
                rate: this.profitSettings.profit_rate,
                amount: profitAmount,
                minProfit: this.profitSettings.min_profit
            },
            totals: {
                costCny: totalCost,
                finalCny: finalPriceCny,
                finalUsd: finalPriceUsd,
                exchangeRate: this.exchangeRate
            },
            breakdown: {
                productCost: {
                    label: '产品成本',
                    value: productCost,
                    percentage: (productCost / finalPriceCny * 100).toFixed(1)
                },
                logisticsCost: {
                    label: '物流费用',
                    value: logisticsResult.logisticsCost,
                    percentage: (logisticsResult.logisticsCost / finalPriceCny * 100).toFixed(1)
                },
                tariffCost: {
                    label: '关税费用',
                    value: tariffCost,
                    percentage: (tariffCost / finalPriceCny * 100).toFixed(1)
                },
                profitAmount: {
                    label: '利润',
                    value: profitAmount,
                    percentage: (profitAmount / finalPriceCny * 100).toFixed(1)
                }
            }
        };

        return quote;
    }

    // 比较多个服务的价格
    async compareServices(productName, weight, unitPriceCny, countryCode) {
        const services = this.getCountryServices(countryCode);
        const comparisons = [];

        for (let service of services) {
            try {
                const quote = await this.calculateQuote(
                    productName, weight, unitPriceCny, countryCode, service.code
                );
                comparisons.push(quote);
            } catch (error) {
                console.warn(`Service ${service.code} calculation failed:`, error.message);
            }
        }

        // 按最终美元价格排序
        comparisons.sort((a, b) => a.totals.finalUsd - b.totals.finalUsd);
        return comparisons;
    }

    // 批量计算多个国家的最优价格
    async calculateBestPrices(productName, weight, unitPriceCny) {
        const countries = this.getAvailableCountries();
        const bestPrices = [];

        for (let country of countries) {
            try {
                const services = this.getCountryServices(country.code);
                if (services.length === 0) continue;

                // 计算该国家最便宜的服务
                let bestQuote = null;
                for (let service of services) {
                    try {
                        const quote = await this.calculateQuote(
                            productName, weight, unitPriceCny, country.code, service.code
                        );
                        if (!bestQuote || quote.totals.finalUsd < bestQuote.totals.finalUsd) {
                            bestQuote = quote;
                        }
                    } catch (error) {
                        continue;
                    }
                }

                if (bestQuote) {
                    bestPrices.push(bestQuote);
                }
            } catch (error) {
                console.warn(`Country ${country.code} calculation failed:`, error.message);
            }
        }

        // 按最终美元价格排序
        bestPrices.sort((a, b) => a.totals.finalUsd - b.totals.finalUsd);
        return bestPrices;
    }

    // 生成报价文本（用于复制）
    generateQuoteText(quote) {
        return `
🎯 智能报价单

📦 产品信息:
• 产品名称: ${quote.productName}
• 重量: ${quote.weight}kg
• 单价: ¥${quote.unitPriceCny}/kg

🚚 物流信息:
• 目的地: ${quote.logistics.countryName}
• 服务: ${quote.logistics.serviceName}
• 时效: ${quote.logistics.deliveryTime}天
• 重量段: ${quote.logistics.weightTier.minWeight}-${quote.logistics.weightTier.maxWeight}kg

💰 费用明细:
• 产品成本: ¥${quote.productCost.toFixed(2)} (${quote.breakdown.productCost.percentage}%)
• 物流费用: ¥${quote.logistics.cost.toFixed(2)} (${quote.breakdown.logisticsCost.percentage}%)
• 关税费用: ¥${quote.tariff.cost.toFixed(2)} (${quote.breakdown.tariffCost.percentage}%)
• 利润: ¥${quote.profit.amount.toFixed(2)} (${quote.breakdown.profitAmount.percentage}%)

🔥 最终报价:
• 人民币: ¥${quote.totals.finalCny.toFixed(2)}
• 美元: $${quote.totals.finalUsd.toFixed(2)} (汇率: ${quote.totals.exchangeRate})

⚡ 由智能报价机器人生成 ${new Date().toLocaleString('zh-CN')}
`.trim();
    }

    // 更新利润设置
    async updateProfitSettings(settings) {
        this.profitSettings = { ...this.profitSettings, ...settings };
        await chrome.storage.local.set({ 'profit_settings': this.profitSettings });
    }

    // 更新汇率
    async updateExchangeRate(rate) {
        this.exchangeRate = rate;
        await chrome.storage.local.set({ 'exchange_rate': rate });
    }
}

// 导出供其他模块使用
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EnhancedPriceCalculator;
} else {
    window.EnhancedPriceCalculator = EnhancedPriceCalculator;
} 